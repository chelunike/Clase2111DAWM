create database Ejercicio4
use Ejercicio4

create table Aparato(
    Cod_aparato int identity (100, 1) primary key,
    desc_aparato varchar (100),
    estado_aparato varchar(7) check (estado_aparato='bueno' or estado_aparato='malo' or estado_aparato='regular'),
    )
insert into Aparato values('Prensa de piernas', 'bueno')
insert into Aparato values('Dorsalera', 'malo')
insert into Aparato values('M�quinas de femorales', 'regular')
insert into Aparato values('Poleas cruzadas', 'regular')
insert into Aparato values('Peck Deck', 'bueno')
insert into Aparato values('M�quina de abductores', 'regular')

create table Sala(
    IDSala int identity (100, 1) primary key,
    metros int,
    ubicacion varchar(40),
    tipo varchar(8) check (tipo='cardio' or tipo='general' or tipo='muscular')
    )
insert into Sala values (50, 'area norte', 'cardio')
insert into Sala values (90, 'area sur', 'general')
insert into Sala values (60, 'area este', 'cardio')
insert into Sala values (30, 'area oeste', 'muscular')
insert into Sala values (50, 'area noroeste', 'muscular')
insert into Sala values (50, 'area sureste', 'general')

create table Clase(
    Cod_clase int identity (50, 1) primary key,
    desc_clase varchar (40)
    )
insert into Clase values('Clase de acrobacias')
insert into Clase values('Clase de danza tradicional')
insert into Clase values('Clase de gimnasia con musica')
insert into Clase values('Clase de baile')
create table Monitor(
    Cod_monitor int identity (10, 1) primary key,
    nombre varchar(40) not null,
    telefono int check (telefono>100000000),
    titulo varchar(2) check (titulo='Si' or titulo='No'),
    claseImpartida varchar(20)
    )
insert into Monitor values ('Paco Mer', 685987642,'No', 'Danza')
insert into Monitor values ('Tomas Turbao', 654851356,'Si', 'Aerobic')
insert into Monitor values ('Aitor Menta', 615887023,'Si', 'Acrosport')
insert into Monitor values ('Juancho Talarga', 615887023,'No', 'Zumba')

-------------------------------------------------

Create table Imparte(
    CodigoC int references Clase,
    CodigoM int references Monitor,
    dia varchar(8),
    hora int,
    constraint PK_Imparte primary key(CodigoC, CodigoM)
)
select * from Monitor
select * from Clase
insert into Imparte values(51,10,'Lunes',12)
insert into Imparte values(53,13,'Martes',18)
insert into Imparte values(52,11,'Viernes',12)
insert into Imparte values(50,12,'Lunes',18)
--------------------------------------------------
-- ver si algun numero se repite

select telefono, COUNT (*)
 from monitor
group by telefono

-- contar los monitores que tiene titulos y los que no tienen

select titulo,  COUNT (*) from Monitor group by titulo 

--contar cuantas salas hay de cada tipo
	
select metros, COUNT(*) from Sala group by metros


-- Quien es el entrenador que esta en la primera posicion

select top 1 with ties * from Monitor
order by telefono desc

-- Media de los metros de las salas

select AVG(metros) from Sala

--Cuando la ubicacion sea area norte se le da un apodo

select *, case when ubicacion='area norte' then 'AN'
else 'AS' end
from Sala

-- Seleccionar que dias hay de clases

select dia from Imparte


-- Seleccionar la sala que tenga menos de 60 metros y su ubicacion

select metros , ubicacion
  from Sala
 where metros > 60
 
 -- decir cuales de los aparatos estan en la condicion bueno
 
 select estado_aparato,desc_aparato from Aparato
 where estado_aparato='bueno' 