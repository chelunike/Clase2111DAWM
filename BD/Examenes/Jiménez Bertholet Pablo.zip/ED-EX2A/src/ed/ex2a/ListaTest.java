
package ed.ex2a;


public class ListaTest {
Lista i1, i2, i4, i5, i6;
public ListaTest() {
i1= new Lista(); i1.añadir("uno"); i1.añadir("dos"); i1.añadir("tres");
i2= new Lista(); i2.añadir("cuatro"); i2.añadir("dos"); i2.añadir("tres");
i4= new Lista(); i4.añadir("uno");
i5= new Lista();
i6= new Lista(); i6.añadir("tres"); i6.añadir("cuatro");
i6.añadir("cinco"); i6.añadir("algo");
}
@Test
public void testLongitud() {
System.out.println("longitud");
assertEquals(3, i1.longitud());
assertEquals(1, i4.longitud());
assertEquals(0, i5.longitud());
}
@Test
public void testAñadir() {
System.out.println("añadir");
Lista i3= new Lista(); i3.añadir("cinco"); i3.añadir("tres"); i3.añadir("dos");
assertEquals(-1, i3.añadir("dos"));
assertEquals(-2, i3.añadir(""));
assertEquals(0, i3.añadir("cuatro"));
assertEquals(0, i3.añadir("01234567890123456789012345"));
assertEquals("01234567890123456789", i3.coger(4));
assertEquals("cuatro", i3.coger(3));
}
@Test
public void testCoger() {
System.out.println("coger");
assertEquals("uno", i1.coger(0));
assertEquals("tres", i1.coger(2));
assertEquals("", i1.coger(3));
assertEquals("", i1.coger(-8));
}
@Test
public void testOrdenadoAlfabeticoDescendente() {
System.out.println("ordenadoAlfabeticoDescendente");
assertEquals(false, i1.ordenadoAlfabeticoDescendente());
assertEquals(true, i6.ordenadoAlfabeticoDescendente());
assertEquals(true, i4.ordenadoAlfabeticoDescendente());
}
@Test
public void testOrdenadoLongitudAscendente() {
System.out.println("ordenadoLongitudAscendente");
assertEquals(true, i1.ordenadoLongitudAscendente());
assertEquals(false, i2.ordenadoLongitudAscendente());
assertEquals(true, i5.ordenadoLongitudAscendente());
}
@Test
public void testLimpiar() {
System.out.println("limpiar");
Lista i3= new Lista(); i3.añadir("cinco"); i3.añadir("tres"); i3.añadir("dos");
assertEquals(3, i3.longitud());
i3.limpiar();
assertEquals(0, i3.longitud());
}
}
