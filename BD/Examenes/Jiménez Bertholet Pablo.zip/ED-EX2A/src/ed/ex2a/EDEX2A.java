
package ed.ex2a;

import java.util.ArrayList;


public class EDEX2A {
    private String i1 = null;
    private String i2 = null;
    private String i3 = null;
    private String i4 = null;
    private String i5 = null;
    private String i6 = null;

    private ArrayList<String> ListaTest = new ArrayList<>();

public void longitud(){
     for (int i = 0; i < ListaTest.size(); i++) {
         System.out.println(+i);
        
    }
 
 
 }
public void añadir(){
    for (int i = 0; i < ListaTest.size(); i++) {
        String i1 = null;
        ListaTest.add(1, i1);
        ListaTest.add(2, i2);
        ListaTest.add(3, i3);
        ListaTest.add(4, i4);
        ListaTest.add(5, i5);
        ListaTest.add(6, i6);
        
    }
}
    

    public static void main(String[] args) {
       
    }
    
}
